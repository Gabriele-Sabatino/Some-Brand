# SOME-BRAND
This is a SOEN287 Project: Building a Grocery Store Website

# ABOUT SOME BRAND
SOME Brand is a grocery store that has some products from some country.

# URL
https://synthia22.github.io/SOME-Grocery/SOME/
